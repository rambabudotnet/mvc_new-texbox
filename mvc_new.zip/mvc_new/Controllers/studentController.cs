﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_new.Models;

namespace mvc_new.Controllers
{
    public class studentController : Controller
    {
        DatabaseContext _db = new DatabaseContext();
        public ActionResult create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult create(tblstudent _stu)
        {
            _db.tblstudents.Add(_stu);
            _db.SaveChanges();   
            return View();
        }
        public ActionResult SHOW()
        {
            var data = _db.tblstudents.ToList();
            return View(data);
        }
    }
}